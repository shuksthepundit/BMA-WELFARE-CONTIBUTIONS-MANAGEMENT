# BMA Welfare Contribution Platform

Web platform built from the *BMA Welfare Mobile Platform* workbook and deck (Phase 1 + parts of Phase 2).

## Run
    npm install
    npm start            # http://localhost:3000   (needs Node >= 22.13)

First start creates `data/bma.db` and imports `data/seed.json` (24 members, 79 contributions = KSh 23,500).
Logins: `admin`, `treasurer`, `auditor`, or a member ID such as `BMA-0013`. Default password `ChangeMe123!` (override with `DEFAULT_PASSWORD`).
**Before real use:** set `SECRET`, change every password, run behind HTTPS, back up `data/bma.db` daily.

## What is implemented
| Blueprint item | Where |
|---|---|
| Roles: Member / Treasurer / Admin / Auditor | `auth()` middleware + role tabs |
| Member register, activate/deactivate | `/api/members` |
| Ledger: PENDING → VERIFIED / CANCELLED, VERIFIED → REVERSED (nothing deleted) | `/api/contributions` |
| Duplicate warning, reference uniqueness, verifier ≠ enterer | `POST /api/contributions`, `/:id/verify` |
| Automatic individual / monthly / collective totals (verified only) | `totals()` |
| Dashboard, monthly summary, exception report, member statement | `/api/dashboard`, `/api/reports/*`, `/api/statement/:id` |
| Audit trail, CSV export | `/api/audit`, `/api/export/{ledger,totals}.csv` |

## Next steps (roadmap)
- Phase 2: PDF receipts/statements (e.g. `pdfkit`), XLSX export.
- Phase 3: M-Pesa Daraja STK push + C2B callback → insert `PENDING` contribution, match by reference; SMS (Africa's Talking).
- Phase 4: trend / arrears analytics. Move to PostgreSQL by porting the `db` helpers (`all/one/run`).
