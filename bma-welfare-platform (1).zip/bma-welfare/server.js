// BMA Welfare Contribution Platform - API + static web app. Node >=22.13, SQLite, Express.
const express = require('express'), crypto = require('crypto'), path = require('path'), fs = require('fs');
const { DatabaseSync } = require('node:sqlite');
const SECRET = process.env.SECRET || 'change-me-in-production';
const db = new DatabaseSync(process.env.DB || path.join(__dirname, 'data', 'bma.db'));
const MONTHS = ['JANUARY','FEBRUARY','MARCH','APRIL','MAY','JUNE','JULY','AUGUST','SEPTEMBER','OCTOBER','NOVEMBER','DECEMBER'];

db.exec(`
CREATE TABLE IF NOT EXISTS members(id TEXT PRIMARY KEY, name TEXT NOT NULL, phone TEXT, email TEXT, join_date TEXT,
  status TEXT DEFAULT 'ACTIVE' CHECK(status IN('ACTIVE','INACTIVE','SUSPENDED')), monthly_target REAL DEFAULT 300, notes TEXT);
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, username TEXT UNIQUE, pw TEXT, role TEXT CHECK(role IN('ADMIN','TREASURER','AUDITOR','MEMBER')), member_id TEXT);
CREATE TABLE IF NOT EXISTS contributions(id TEXT PRIMARY KEY, member_id TEXT NOT NULL, month INTEGER, year INTEGER, amount REAL NOT NULL,
  payment_date TEXT, method TEXT DEFAULT 'Manual', reference TEXT, status TEXT DEFAULT 'PENDING' CHECK(status IN('PENDING','VERIFIED','REVERSED','CANCELLED')),
  entered_by TEXT, verified_by TEXT, verified_at TEXT, notes TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY, user TEXT, action TEXT, entity TEXT, entity_id TEXT, detail TEXT, ts TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS settings(k TEXT PRIMARY KEY, v TEXT);
`);
const all = (q, ...a) => db.prepare(q).all(...a), one = (q, ...a) => db.prepare(q).get(...a), run = (q, ...a) => db.prepare(q).run(...a);
const setting = (k, d) => (one('SELECT v FROM settings WHERE k=?', k) || { v: d }).v;
const log = (u, action, entity, id, detail = '') => run('INSERT INTO audit(user,action,entity,entity_id,detail) VALUES(?,?,?,?,?)', u, action, entity, String(id), typeof detail === 'string' ? detail : JSON.stringify(detail));

// ---- auth (scrypt passwords + HMAC-signed bearer tokens) ----
const hash = (pw, salt = crypto.randomBytes(16).toString('hex')) => salt + ':' + crypto.scryptSync(pw, salt, 32).toString('hex');
const check = (pw, h) => { const [s] = h.split(':'); return crypto.timingSafeEqual(Buffer.from(hash(pw, s)), Buffer.from(h)); };
const sign = p => { const b = Buffer.from(JSON.stringify({ ...p, exp: Date.now() + 12 * 3600e3 })).toString('base64url'); return b + '.' + crypto.createHmac('sha256', SECRET).update(b).digest('base64url'); };
const verify = t => { const [b, s] = (t || '').split('.'); if (!b || s !== crypto.createHmac('sha256', SECRET).update(b).digest('base64url')) return null; const p = JSON.parse(Buffer.from(b, 'base64url')); return p.exp > Date.now() ? p : null; };
const auth = (...roles) => (req, res, next) => {
  const u = verify((req.headers.authorization || '').replace('Bearer ', ''));
  if (!u) return res.status(401).json({ error: 'Login required' });
  if (roles.length && !roles.includes(u.role)) return res.status(403).json({ error: 'Not permitted for your role' });
  req.user = u; next();
};

// ---- seed from the Excel blueprint (data/seed.json) ----
function seed() {
  if (one('SELECT COUNT(*) n FROM members').n) return;
  const s = JSON.parse(fs.readFileSync(path.join(__dirname, 'data', 'seed.json')));
  const pw = process.env.DEFAULT_PASSWORD || 'ChangeMe123!';
  db.exec('BEGIN');
  for (const m of s.members) {
    run('INSERT INTO members(id,name,phone,email,status,monthly_target) VALUES(?,?,?,?,?,?)', m.id, m.name, m.phone, m.email, m.status, m.target);
    run('INSERT INTO users(username,pw,role,member_id) VALUES(?,?,?,?)', m.id, hash(pw), 'MEMBER', m.id);
  }
  for (const r of ['admin', 'treasurer', 'auditor']) run('INSERT INTO users(username,pw,role) VALUES(?,?,?)', r, hash(pw), r.toUpperCase());
  s.contributions.forEach((c, i) => run(`INSERT INTO contributions(id,member_id,month,year,amount,method,status,entered_by,verified_by,notes) VALUES(?,?,?,?,?,?,'VERIFIED','import','import','Imported from workbook')`,
    'CON-' + String(i + 1).padStart(5, '0'), c.member_id, MONTHS.indexOf(c.month) + 1, c.year, c.amount, c.method));
  run("INSERT OR REPLACE INTO settings VALUES('standard_amount','300'),('start_period','2026-06')");
  log('system', 'IMPORT', 'workbook', '-', `${s.members.length} members, ${s.contributions.length} contributions`);
  db.exec('COMMIT');
  console.log(`Seeded. Logins: admin / treasurer / auditor / BMA-00NN  password: ${pw}`);
}
seed();

// ---- calculation engine: everything derives from VERIFIED transactions ----
function periods() {
  const [sy, sm] = setting('start_period', '2026-06').split('-').map(Number), now = new Date(), out = [];
  const last = one("SELECT MAX(year*100+month) p FROM contributions WHERE status='VERIFIED'").p || 0;
  const end = Math.max(now.getFullYear() * 100 + now.getMonth() + 1, last);
  for (let y = sy, m = sm; y * 100 + m <= end; m === 12 ? (y++, m = 1) : m++) out.push({ year: y, month: m, label: MONTHS[m - 1].slice(0, 3) + ' ' + y });
  return out;
}
function totals() {
  const P = periods(), members = all("SELECT * FROM members ORDER BY id"), tx = all("SELECT * FROM contributions WHERE status='VERIFIED'");
  const cell = {}; tx.forEach(t => { const k = t.member_id + t.year + '-' + t.month; cell[k] = (cell[k] || 0) + t.amount; });
  const rows = members.map(m => {
    const by = P.map(p => cell[m.id + p.year + '-' + p.month] || 0), total = by.reduce((a, b) => a + b, 0);
    const active = m.status === 'ACTIVE', expected = active ? m.monthly_target * P.length : total;
    return { id: m.id, name: m.name, status: m.status, by, total, expected, variance: total - expected, participation: P.length ? by.filter(x => x > 0).length / P.length : 0 };
  });
  const monthly = P.map((p, i) => {
    const paid = rows.filter(r => r.by[i] > 0).length, act = members.filter(m => m.status === 'ACTIVE').length;
    const collected = rows.reduce((a, r) => a + r.by[i], 0), expected = members.filter(m => m.status === 'ACTIVE').reduce((a, m) => a + m.monthly_target, 0);
    return { ...p, paid, unpaid: Math.max(act - paid, 0), collected, expected, variance: collected - expected, rate: act ? paid / act : 0 };
  });
  return { periods: P, rows, monthly, collective: rows.reduce((a, r) => a + r.total, 0) };
}

const app = express();
app.use(express.json()); app.use(express.static(path.join(__dirname, 'public')));
const wrap = f => (req, res) => { try { f(req, res); } catch (e) { res.status(400).json({ error: e.message }); } };

app.post('/api/login', wrap((req, res) => {
  const u = one('SELECT * FROM users WHERE username=?', String(req.body.username || '').trim());
  if (!u || !check(String(req.body.password || ''), u.pw)) return res.status(401).json({ error: 'Invalid credentials' });
  log(u.username, 'LOGIN', 'user', u.id);
  res.json({ token: sign({ id: u.id, username: u.username, role: u.role, member_id: u.member_id }), role: u.role, username: u.username, member_id: u.member_id });
}));
app.post('/api/password', auth(), wrap((req, res) => {
  if (String(req.body.password || '').length < 8) throw new Error('Password must be at least 8 characters');
  run('UPDATE users SET pw=? WHERE id=?', hash(req.body.password), req.user.id); log(req.user.username, 'PASSWORD_CHANGE', 'user', req.user.id); res.json({ ok: true });
}));

// members
app.get('/api/members', auth('ADMIN', 'TREASURER', 'AUDITOR'), (q, r) => r.json(all('SELECT * FROM members ORDER BY id')));
app.post('/api/members', auth('ADMIN'), wrap((req, res) => {
  const b = req.body; if (!b.name) throw new Error('Name required');
  const n = one("SELECT MAX(CAST(SUBSTR(id,5) AS INTEGER)) n FROM members").n || 0, id = 'BMA-' + String(n + 1).padStart(4, '0');
  run('INSERT INTO members(id,name,phone,email,join_date,monthly_target) VALUES(?,?,?,?,?,?)', id, b.name, b.phone || '', b.email || '', b.join_date || new Date().toISOString().slice(0, 10), b.monthly_target || +setting('standard_amount', 300));
  run('INSERT INTO users(username,pw,role,member_id) VALUES(?,?,?,?)', id, hash(process.env.DEFAULT_PASSWORD || 'ChangeMe123!'), 'MEMBER', id);
  log(req.user.username, 'CREATE', 'member', id, b.name); res.json({ id });
}));
app.put('/api/members/:id', auth('ADMIN'), wrap((req, res) => {
  const b = req.body; run('UPDATE members SET name=COALESCE(?,name),phone=COALESCE(?,phone),email=COALESCE(?,email),status=COALESCE(?,status),monthly_target=COALESCE(?,monthly_target),notes=COALESCE(?,notes) WHERE id=?',
    b.name ?? null, b.phone ?? null, b.email ?? null, b.status ?? null, b.monthly_target ?? null, b.notes ?? null, req.params.id);
  log(req.user.username, 'EDIT', 'member', req.params.id, b); res.json({ ok: true });
}));

// contributions: PENDING -> VERIFIED / CANCELLED ; VERIFIED -> REVERSED (never deleted)
app.get('/api/contributions', auth('ADMIN', 'TREASURER', 'AUDITOR'), (req, res) => {
  const { status, member_id, year, month } = req.query, w = [], a = [];
  [['status', status], ['member_id', member_id], ['year', year], ['month', month]].forEach(([k, v]) => v && (w.push(k + '=?'), a.push(v)));
  res.json(all(`SELECT c.*, m.name member_name FROM contributions c JOIN members m ON m.id=c.member_id ${w.length ? 'WHERE ' + w.join(' AND ') : ''} ORDER BY c.created_at DESC, c.id DESC`, ...a));
});
app.post('/api/contributions', auth('ADMIN', 'TREASURER'), wrap((req, res) => {
  const b = req.body, amount = Number(b.amount);
  if (!one('SELECT 1 FROM members WHERE id=?', b.member_id)) throw new Error('Unknown member');
  if (!(amount > 0) || !b.month || !b.year) throw new Error('Member, period and a positive amount are required');
  const dup = one("SELECT id FROM contributions WHERE member_id=? AND month=? AND year=? AND status IN('VERIFIED','PENDING')", b.member_id, b.month, b.year);
  if (dup && !b.confirm_duplicate) return res.status(409).json({ error: `Duplicate warning: ${dup.id} already exists for this member and period`, duplicate: dup.id });
  if (b.reference && one("SELECT id FROM contributions WHERE reference=? AND status!='CANCELLED'", b.reference)) throw new Error('Reference already used');
  const id = 'CON-' + String((one('SELECT COUNT(*) n FROM contributions').n) + 1).padStart(5, '0');
  run('INSERT INTO contributions(id,member_id,month,year,amount,payment_date,method,reference,entered_by,notes) VALUES(?,?,?,?,?,?,?,?,?,?)',
    id, b.member_id, b.month, b.year, amount, b.payment_date || new Date().toISOString().slice(0, 10), b.method || 'Manual', b.reference || '', req.user.username, b.notes || '');
  log(req.user.username, 'CREATE', 'contribution', id, b); res.json({ id });
}));
app.post('/api/contributions/:id/:action', auth('ADMIN', 'TREASURER'), wrap((req, res) => {
  const c = one('SELECT * FROM contributions WHERE id=?', req.params.id), act = req.params.action;
  const next = { verify: ['PENDING', 'VERIFIED'], reject: ['PENDING', 'CANCELLED'], reverse: ['VERIFIED', 'REVERSED'] }[act];
  if (!c || !next || c.status !== next[0]) throw new Error('Action not allowed for current status');
  if (act === 'verify' && c.entered_by === req.user.username && req.user.role !== 'ADMIN') throw new Error('Segregation of duties: another officer must verify');
  if (act === 'reverse' && !req.body.reason) throw new Error('A reason is required to reverse');
  run(`UPDATE contributions SET status=?, verified_by=?, verified_at=CURRENT_TIMESTAMP, notes=COALESCE(notes,'')||? WHERE id=?`, next[1], req.user.username, req.body.reason ? ` [${act}: ${req.body.reason}]` : '', c.id);
  log(req.user.username, act.toUpperCase(), 'contribution', c.id, req.body.reason || ''); res.json({ status: next[1] });
}));

// reports
app.get('/api/totals', auth('ADMIN', 'TREASURER', 'AUDITOR'), (q, r) => r.json(totals()));
app.get('/api/dashboard', auth('ADMIN', 'TREASURER', 'AUDITOR'), (q, r) => {
  const t = totals(), cur = t.monthly[t.monthly.length - 1] || {};
  r.json({ members: t.rows.filter(x => x.status === 'ACTIVE').length, collective: t.collective, standard: +setting('standard_amount', 300), current: cur, monthly: t.monthly,
    pending: one("SELECT COUNT(*) n FROM contributions WHERE status='PENDING'").n, exceptions: exceptions().length });
});
function exceptions() {
  const std = +setting('standard_amount', 300);
  return [
    ...all("SELECT c.*,m.name member_name,'NON-STANDARD AMOUNT' issue FROM contributions c JOIN members m ON m.id=c.member_id JOIN (SELECT id,monthly_target FROM members) t ON t.id=c.member_id WHERE c.status='VERIFIED' AND c.amount!=t.monthly_target"),
    ...all("SELECT c.*,m.name member_name,'DUPLICATE PERIOD' issue FROM contributions c JOIN members m ON m.id=c.member_id WHERE c.status='VERIFIED' AND (SELECT COUNT(*) FROM contributions d WHERE d.member_id=c.member_id AND d.month=c.month AND d.year=c.year AND d.status='VERIFIED')>1"),
    ...all("SELECT c.*,m.name member_name,'UNVERIFIED' issue FROM contributions c JOIN members m ON m.id=c.member_id WHERE c.status='PENDING'"),
    ...all("SELECT c.*,m.name member_name,'REVERSED' issue FROM contributions c JOIN members m ON m.id=c.member_id WHERE c.status='REVERSED'")];
}
app.get('/api/reports/exceptions', auth('ADMIN', 'TREASURER', 'AUDITOR'), (q, r) => r.json(exceptions()));
app.get('/api/audit', auth('ADMIN', 'AUDITOR'), (q, r) => r.json(all('SELECT * FROM audit ORDER BY id DESC LIMIT 500')));
app.get('/api/statement/:id', auth(), wrap((req, res) => {   // members may only see their own
  if (req.user.role === 'MEMBER' && req.user.member_id !== req.params.id) return res.status(403).json({ error: 'You can only view your own statement' });
  const m = one('SELECT * FROM members WHERE id=?', req.params.id), t = totals(), row = t.rows.find(x => x.id === req.params.id);
  if (!m) throw new Error('Unknown member');
  let run_ = 0; const lines = all("SELECT * FROM contributions WHERE member_id=? AND status='VERIFIED' ORDER BY year,month,id", m.id).map(c => ({ ...c, running: (run_ += c.amount) }));
  res.json({ member: m, periods: t.periods, summary: row, lines });
}));
app.get('/api/export/:kind.csv', auth('ADMIN', 'TREASURER', 'AUDITOR'), (req, res) => {
  const q = s => `"${String(s ?? '').replace(/"/g, '""')}"`, t = totals(); let head, rows;
  if (req.params.kind === 'ledger') { head = ['id', 'member_id', 'member_name', 'month', 'year', 'amount', 'payment_date', 'method', 'reference', 'status', 'entered_by', 'verified_by'];
    rows = all('SELECT c.*,m.name member_name FROM contributions c JOIN members m ON m.id=c.member_id ORDER BY c.id'); }
  else if (req.params.kind === 'totals') { head = ['id', 'name', ...t.periods.map(p => p.label), 'total', 'expected', 'variance']; rows = t.rows.map(r => ({ id: r.id, name: r.name, ...Object.fromEntries(t.periods.map((p, i) => [p.label, r.by[i]])), total: r.total, expected: r.expected, variance: r.variance })); }
  else return res.status(404).end();
  log(req.user.username, 'EXPORT', 'report', req.params.kind);
  res.type('text/csv').attachment(`bma-${req.params.kind}.csv`).send([head.join(','), ...rows.map(r => head.map(h => q(r[h])).join(','))].join('\n'));
});

if (process.argv.includes('--seed')) process.exit(0);
app.listen(process.env.PORT || 3000, () => console.log('BMA Welfare platform on http://localhost:' + (process.env.PORT || 3000)));
